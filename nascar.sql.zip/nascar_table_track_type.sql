
-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `track_type`
--

DROP TABLE IF EXISTS `track_type`;
CREATE TABLE `track_type` (
  `ID` int NOT NULL,
  `Type` varchar(127) NOT NULL,
  `Surface` varchar(127) NOT NULL,
  `ColorCode` varchar(7) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT '#FFFFFF',
  `Comment` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- TRUNCATE Tabelle vor dem Einfügen `track_type`
--

TRUNCATE TABLE `track_type`;
--
-- Daten für Tabelle `track_type`
--

INSERT INTO `track_type` (`ID`, `Type`, `Surface`, `ColorCode`, `Comment`) VALUES
(0, 'Dummy', 'Dummy', '', '0'),
(11, 'Short Oval', 'dirt', '#B89C50', '3/8 miles'),
(12, 'Short Oval', 'mixed', '', '3/8 miles'),
(13, 'Short Oval', 'concrete', '#FBEFEF', '3/8 miles'),
(14, 'Short Oval', 'concrete/asphalt', '#FBEFEF', '3/8 miles'),
(15, 'Short Oval', 'asphalt', '#FBEFEF', '3/8 miles'),
(16, 'Short Oval', 'paved', '#FBEFEF', '3/8 miles'),
(21, 'Short Oval', 'dirt', '#B89C50', '1/2 miles'),
(22, 'Short Oval', 'mixed', '', '1/2 miles'),
(23, 'Short Oval', 'concrete', '#F6CECE', '1/2 miles'),
(24, 'Short Oval', 'concrete/asphalt', '#F6CECE', '1/2 miles'),
(25, 'Short Oval', 'asphalt', '#F6CECE', '1/2 miles'),
(26, 'Short Oval', 'paved', '#F6CECE', '1/2 miles'),
(31, 'Short Oval', 'dirt', '#B89C50', '5/8 miles'),
(32, 'Short Oval', 'mixed', '', '5/8 miles'),
(33, 'Short Oval', 'concrete', '#F5A9A9', '5/8 miles'),
(34, 'Short Oval', 'concrete/asphalt', '#F5A9A9', '5/8 miles'),
(35, 'Short Oval', 'asphalt', '#F5A9A9', '5/8 miles'),
(36, 'Short Oval', 'paved', '#F5A9A9', '5/8 miles'),
(41, 'Mile Oval', 'dirt', '#B89C50', '1 mile'),
(42, 'Mile Oval', 'mixed', '', '1 mile'),
(43, 'Mile Oval', 'concrete', '#F7819F', '1 mile'),
(44, 'Mile Oval', 'concrete/asphalt', '#F7819F', '1 mile'),
(45, 'Mile Oval', 'asphalt', '#F7819F', '1 mile'),
(46, 'Mile Oval', 'paved', '#F7819F', '1 mile'),
(51, 'Intermediate Oval', 'dirt', '#B89C50', '1.25 miles'),
(52, 'Intermediate Oval', 'mixed', '', '1.25 miles'),
(53, 'Intermediate Oval', 'concrete', '#F08080', '1.25 miles'),
(54, 'Intermediate Oval', 'concrete/asphalt', '#F08080', '1.25 miles'),
(55, 'Intermediate Oval', 'asphalt', '#F08080', '1.25 miles'),
(56, 'Intermediate Oval', 'paved', '#F08080', '1.25 miles'),
(61, 'Speedway', 'dirt', '#B89C50', '1.5 miles'),
(62, 'Speedway', 'mixed', '', '1.5 miles'),
(63, 'Speedway', 'concrete', '#F08080', '1.5 miles'),
(64, 'Speedway', 'concrete/asphalt', '#F08080', '1.5 miles'),
(65, 'Speedway', 'asphalt', '#F08080', '1.5 miles'),
(66, 'Speedway', 'paved', '#F08080', '1.5 miles'),
(71, 'Superspeedway', 'dirt', '#B89C50', '2.0 miles'),
(72, 'Superspeedway', 'mixed', '', '2.0 miles'),
(73, 'Superspeedway', 'concrete', '#DB7093', '2.0 miles'),
(74, 'Superspeedway', 'concrete/asphalt', '#DB7093', '2.0 miles'),
(75, 'Superspeedway', 'asphalt', '#DB7093', '2.0 miles'),
(76, 'Superspeedway', 'paved', '#DB7093', '2.0 miles'),
(81, 'Superspeedway', 'dirt', '#B89C50', '2.5 miles'),
(82, 'Superspeedway', 'mixed', '', '2.5 miles'),
(83, 'Superspeedway', 'concrete', '#CD5C5C', '2.5 miles'),
(84, 'Superspeedway', 'concrete/asphalt', '#CD5C5C', '2.5 miles'),
(85, 'Superspeedway', 'asphalt', '#CD5C5C', '2.5 miles'),
(86, 'Superspeedway', 'paved', '#CD5C5C', '2.5 miles'),
(90, 'Roval', 'paved/concrete', '#9BCD9B', 'Infield Road Course of Oval Track'),
(91, 'Road Course', 'dirt', '#B89C50', 'Beach or offroad'),
(92, 'Road Course', 'mixed', '#9ACD32', 'Mixed dirt and paved'),
(93, 'Road Course', 'concrete/asphalt', '#7CCD7C', ''),
(94, 'Road Course', 'paved', '#7CCD7C', 'Natural Terrain Course'),
(95, 'Street Course', 'paved/concrete', '#79CDCD', 'Public Streets '),
(96, 'Street Course', 'paved/concrete', '#9FB6CD', 'City Streets'),
(97, 'Airfield Course', 'paved/concrete', '#8DEEEE', 'Airfield Roads');
