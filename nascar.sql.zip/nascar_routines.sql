
DELIMITER $$
--
-- Prozeduren
--
DROP PROCEDURE IF EXISTS `10_Fahrerduplikate_im_Hauptrennen_finden`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `10_Fahrerduplikate_im_Hauptrennen_finden` ()  READS SQL DATA
SELECT RaceID, race_results.DriverID, COUNT(Finish) FROM race_results GROUP BY RaceID, race_results.DriverID HAVING COUNT(Finish) > 1$$

DROP PROCEDURE IF EXISTS `10_Fahrerduplikate_im_Sprintennen_finden`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `10_Fahrerduplikate_im_Sprintennen_finden` ()  READS SQL DATA
SELECT RaceID, sprint_results.DriverID, COUNT(Finish) FROM sprint_results GROUP BY RaceID, SprintID, sprint_results.DriverID HAVING COUNT(Finish) > 1$$

DROP PROCEDURE IF EXISTS `11_Datenfehler_im Hauptrennen_finden`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `11_Datenfehler_im Hauptrennen_finden` ()  READS SQL DATA
BEGIN
SELECT RaceID, COUNT(DISTINCT Start), MAX(Start), COUNT(DISTINCT Finish), Max(Finish) FROM race_results GROUP BY RaceID HAVING COUNT(DISTINCT Start) <> COUNT(DISTINCT Finish) OR (MAX(Start) <> MAX(Finish)) OR (COUNT(DISTINCT Finish) <> MAX(Finish)) ORDER BY RaceID DESC Limit 25;

SELECT RaceID, SUM(Led), MAX(Laps) FROM race_results GROUP BY RaceID HAVING (SUM(Led) <> MAX(Laps)) ORDER BY RaceID DESC;
END$$

DROP PROCEDURE IF EXISTS `11_Datenfehler_im Sprintrennen_finden`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `11_Datenfehler_im Sprintrennen_finden` ()  READS SQL DATA
BEGIN
SELECT RaceID, COUNT(DISTINCT Start), MAX(Start), COUNT(DISTINCT Finish), Max(Finish) FROM sprint_results GROUP BY RaceID, SprintID HAVING COUNT(DISTINCT Start) <> COUNT(DISTINCT Finish) OR (MAX(Start) <> MAX(Finish)) OR (COUNT(DISTINCT Finish) <> MAX(Finish)) ORDER BY RaceID DESC Limit 25;

SELECT RaceID, SUM(Led), MAX(Laps) FROM sprint_results GROUP BY RaceID, SprintID HAVING (SUM(Led) <> MAX(Laps)) ORDER BY RaceID DESC;
END$$

DROP PROCEDURE IF EXISTS `21_Meisterschaft_anlegen`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `21_Meisterschaft_anlegen` ()  BEGIN
INSERT INTO championship (Bezeichnung, Saison, RaceID, Kategorie)
SELECT 'NASCAR Cup Series', YEAR(races.Datum), races.ID, 1 FROM races LEFT JOIN championship ON championship.RaceID = races.ID WHERE (championship.ID IS NULL) AND (races.ID MOD 10 IN (1,2,3));

INSERT INTO championship (Bezeichnung, Saison, RaceID, Kategorie)
SELECT 'NASCAR Nationwide Series', YEAR(races.Datum), races.ID, 1 FROM races LEFT JOIN championship ON championship.RaceID = races.ID WHERE (championship.ID IS NULL) AND (races.ID MOD 10 IN (4,5,6));

INSERT INTO championship (Bezeichnung, Saison, RaceID, Kategorie)
SELECT 'NASCAR Truck Series', YEAR(races.Datum), races.ID, 1 FROM races LEFT JOIN championship ON championship.RaceID = races.ID WHERE (championship.ID IS NULL) AND (races.ID MOD 10 IN (7,8,9));

UPDATE championship LEFT JOIN races ON races.ID = championship.RaceID SET races.Event = Concat(championship.Saison, '–') WHERE (races.Event = '') OR (races.Event IS NULL);

UPDATE championship LEFT JOIN races ON races.ID = championship.RaceID LEFT JOIN (SELECT MAX(Finish) AS Cars, RaceID FROM race_results GROUP BY RaceID) AS TempTable ON TempTable.RaceID = races.ID SET championship.Cars = TempTable.Cars WHERE TempTable.Cars IS NOT NULL;

UPDATE championship LEFT JOIN races ON races.ID = championship.RaceID LEFT JOIN (SELECT MAX(championship.Cars) AS Cars, championship.Saison, championship.Bezeichnung FROM championship GROUP BY championship.Saison, championship.Bezeichnung) AS TempTable ON TempTable.Saison = championship.Saison AND  TempTable.Bezeichnung = championship.Bezeichnung SET championship.Cars = TempTable.Cars WHERE championship.Cars IS NULL;

UPDATE championship SET championship.Mileage = 0;
END$$

DROP PROCEDURE IF EXISTS `22_Resort_ChampionshipID`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `22_Resort_ChampionshipID` ()  MODIFIES SQL DATA
BEGIN
SET @max_id = 0;

SELECT COUNT(ID) + 1 INTO @max_id FROM championship;

UPDATE championship LEFT JOIN (SELECT m1.ID, m1.RaceID, count(m2.ID) as NewID FROM `championship` as m1 left join `championship` as m2 on m1.ID >= m2.ID group by m1.ID, m1.RaceID) As Temp on Temp.ID = championship.ID set championship.ID = 10 * Temp.RaceID + 2 * championship.Kategorie + (Temp.NewID mod 10);

UPDATE championship LEFT JOIN (SELECT m1.ID, m1.RaceID, count(m2.ID) as NewID FROM `championship` as m1 left join `championship` as m2 on m1.ID >= m2.ID group by m1.ID, m1.RaceID) As Temp on Temp.ID = championship.ID set championship.ID = Temp.NewID;

SET @sql = CONCAT('ALTER TABLE `championship` AUTO_INCREMENT = ', @max_id);
PREPARE st FROM @sql;
EXECUTE st;

END$$

DROP PROCEDURE IF EXISTS `31_Resort_DriverID`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `31_Resort_DriverID` ()  MODIFIES SQL DATA
BEGIN

UPDATE drivers INNER JOIN race_results ON race_results.DriverID = drivers.ID
SET drivers.Kategorie = 100*race_results.RaceID + race_results.Finish;

UPDATE drivers INNER JOIN race_results ON race_results.DriverID = drivers.ID
SET drivers.ID = drivers.Kategorie - 1.9e+10 WHERE drivers.Kategorie > 0;

UPDATE drivers LEFT JOIN (SELECT d1.ID, d1.Kategorie, count(d2.ID) as NewID FROM `drivers` as d1 left join `drivers` as d2 on d1.ID >= d2.ID group by d1.ID, d1.Kategorie) As Temp on Temp.ID = drivers.ID set drivers.ID = Temp.NewID;

END$$

DROP PROCEDURE IF EXISTS `32_Resort_TrackID`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `32_Resort_TrackID` ()  MODIFIES SQL DATA
BEGIN

UPDATE tracks INNER JOIN races ON races.TrackID = tracks.ID
SET tracks.Kategorie = races.ID;

UPDATE tracks INNER JOIN races ON races.TrackID = tracks.ID
SET tracks.ID = tracks.Kategorie WHERE tracks.Kategorie > 0;

UPDATE tracks LEFT JOIN (SELECT t1.ID, t1.Kategorie, count(t2.ID)-1 as NewID FROM `tracks` as t1 left join `tracks` as t2 on t1.ID >= t2.ID group by t1.ID, t1.Kategorie) As Temp on Temp.ID = tracks.ID set tracks.ID = Temp.NewID;

END$$

DROP PROCEDURE IF EXISTS `41_Punktesysteme_festlegen`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `41_Punktesysteme_festlegen` ()  MODIFIES SQL DATA
BEGIN
UPDATE championship SET championship.Qualification_Scoring = 13 WHERE RaceID IN (SELECT RaceID FROM qualification_results);

UPDATE championship SET championship.Sprint_Scoring = 11 WHERE RaceID IN (SELECT RaceID FROM sprint_results);

UPDATE championship SET championship.Stage_Scoring = 11 WHERE RaceID IN (SELECT RaceID FROM stage_results);

UPDATE championship SET championship.Race_Scoring = championship.Cars + 1;

UPDATE championship LEFT JOIN races ON races.ID = championship.RaceID LEFT JOIN tracks ON tracks.ID = races.TrackID SET championship.Bonus_Scoring = 1 WHERE (races.ID MOD 10 IN (1,2,3));
UPDATE championship LEFT JOIN races ON races.ID = championship.RaceID LEFT JOIN tracks ON tracks.ID = races.TrackID SET championship.Bonus_Scoring = 1 WHERE (races.ID MOD 10 IN (4,5,6));
UPDATE championship LEFT JOIN races ON races.ID = championship.RaceID LEFT JOIN tracks ON tracks.ID = races.TrackID SET championship.Bonus_Scoring = 1 WHERE (races.ID MOD 10 IN (7,8,9));

DELETE FROM championship_scoring;
INSERT INTO championship_scoring (ChampionShipID, DriverID)
SELECT championship.ID, race_results.DriverID
FROM championship INNER JOIN race_results ON race_results.RaceID = championship.RaceID
WHERE race_results.DriverID IS NOT NULL
GROUP BY championship.ID, race_results.DriverID;
END$$

DROP PROCEDURE IF EXISTS `42_Punkte_berechnen`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `42_Punkte_berechnen` ()  MODIFIES SQL DATA
BEGIN
UPDATE championship_scoring SET 
championship_scoring.Rank_Points = 0, 
championship_scoring.Sprint_Points = 0, 
championship_scoring.Stage_Points = 0,
championship_scoring.Qualification_Points = 0,
championship_scoring.Bonus_Points = 0;

UPDATE championship_scoring INNER JOIN championship ON championship.ID = championship_scoring.ChampionshipID 
INNER JOIN race_results ON race_results.RaceID = championship.RaceID AND race_results.DriverID = championship_scoring.DriverID
SET championship_scoring.Rank_Points = championship.Race_Scoring - race_results.Finish
WHERE championship.Race_Scoring > race_results.Finish;

UPDATE championship_scoring INNER JOIN 
(SELECT championship.ID AS ChampionshipID, sprint_results.DriverID, SUM(championship.Sprint_Scoring - sprint_results.Finish) AS SprintPoints FROM sprint_results INNER JOIN championship ON sprint_results.RaceID = championship.RaceID WHERE championship.Sprint_Scoring > sprint_results.Finish GROUP BY championship.ID, sprint_results.DriverID) AS TempTableSprint 
ON TempTableSprint.ChampionshipID = championship_scoring.ChampionshipID AND TempTableSprint.DriverID = championship_scoring.DriverID
SET championship_scoring.Sprint_Points = TempTableSprint.SprintPoints;

UPDATE championship_scoring INNER JOIN 
(SELECT championship.ID AS ChampionshipID, stage_results.DriverID, SUM(championship.Stage_Scoring - stage_results.Position) AS StagePoints FROM stage_results INNER JOIN championship ON stage_results.RaceID = championship.RaceID WHERE championship.Stage_Scoring > stage_results.Position GROUP BY championship.ID, stage_results.DriverID) AS TempTableStage 
ON TempTableStage.ChampionshipID = championship_scoring.ChampionshipID AND TempTableStage.DriverID = championship_scoring.DriverID
SET championship_scoring.Stage_Points = TempTableStage.StagePoints;

UPDATE championship_scoring INNER JOIN 
(SELECT championship.ID AS ChampionshipID, qualification_results.DriverID, SUM(championship.Qualification_Scoring - qualification_results.Position) AS QualificationPoints FROM qualification_results INNER JOIN championship ON qualification_results.RaceID = championship.RaceID WHERE championship.Qualification_Scoring > qualification_results.Position GROUP BY championship.ID, qualification_results.DriverID) AS TempTableQualification 
ON TempTableQualification.ChampionshipID = championship_scoring.ChampionshipID AND TempTableQualification.DriverID = championship_scoring.DriverID
SET championship_scoring.Qualification_Points = TempTableQualification.QualificationPoints;

UPDATE championship_scoring INNER JOIN championship ON championship.ID = championship_scoring.ChampionshipID INNER JOIN bonus_points ON bonus_points.Scoring = championship.Bonus_Scoring
INNER JOIN race_results ON race_results.RaceID = championship.RaceID AND race_results.DriverID = championship_scoring.DriverID
SET championship_scoring.Bonus_Points = championship_scoring.Bonus_Points + bonus_points.Punkte
WHERE (bonus_points.Wert = 1) AND (bonus_points.Bewertung = "WIN") AND (race_results.Finish = 1);

UPDATE championship_scoring INNER JOIN championship ON championship.ID = championship_scoring.ChampionshipID INNER JOIN bonus_points ON bonus_points.Scoring = championship.Bonus_Scoring
INNER JOIN race_results ON race_results.RaceID = championship.RaceID AND race_results.DriverID = championship_scoring.DriverID
SET championship_scoring.Bonus_Points = championship_scoring.Bonus_Points + bonus_points.Punkte
WHERE (bonus_points.Wert = 1) AND (bonus_points.Bewertung = "MPG") AND (race_results.MostPositionsGained = 1);

UPDATE championship_scoring INNER JOIN championship ON championship.ID = championship_scoring.ChampionshipID INNER JOIN bonus_points ON bonus_points.Scoring = championship.Bonus_Scoring
INNER JOIN race_results ON race_results.RaceID = championship.RaceID AND race_results.DriverID = championship_scoring.DriverID
SET championship_scoring.Bonus_Points = championship_scoring.Bonus_Points + bonus_points.Punkte
WHERE (bonus_points.Wert = 1) AND (bonus_points.Bewertung = "LLF") AND (race_results.LedLapFinish = 1);

UPDATE championship_scoring INNER JOIN championship ON championship.ID = championship_scoring.ChampionshipID INNER JOIN bonus_points ON bonus_points.Scoring = championship.Bonus_Scoring
INNER JOIN race_results ON race_results.RaceID = championship.RaceID AND race_results.DriverID = championship_scoring.DriverID
SET championship_scoring.Bonus_Points = championship_scoring.Bonus_Points + bonus_points.Punkte
WHERE (bonus_points.Wert = 1) AND (bonus_points.Bewertung = "LL") AND (race_results.Led > 0);

UPDATE championship_scoring INNER JOIN championship ON championship.ID = championship_scoring.ChampionshipID INNER JOIN bonus_points ON bonus_points.Scoring = championship.Bonus_Scoring
INNER JOIN race_results ON race_results.RaceID = championship.RaceID AND race_results.DriverID = championship_scoring.DriverID
SET championship_scoring.Bonus_Points = championship_scoring.Bonus_Points + bonus_points.Punkte
WHERE (bonus_points.Wert = 1) AND (bonus_points.Bewertung = "MLL") AND (race_results.MostLapsLed = 1);

UPDATE championship_scoring INNER JOIN championship ON championship.ID = championship_scoring.ChampionshipID INNER JOIN bonus_points ON bonus_points.Scoring = championship.Bonus_Scoring
INNER JOIN race_results ON race_results.RaceID = championship.RaceID AND race_results.DriverID = championship_scoring.DriverID
SET championship_scoring.Bonus_Points = championship_scoring.Bonus_Points + bonus_points.Punkte
WHERE (bonus_points.Wert = 1) AND (bonus_points.Bewertung = "FRL") AND (race_results.FastestRaceLap = 1);

UPDATE championship_scoring INNER JOIN championship ON championship.ID = championship_scoring.ChampionshipID INNER JOIN bonus_points ON bonus_points.Scoring = championship.Bonus_Scoring
INNER JOIN race_results ON race_results.RaceID = championship.RaceID AND race_results.DriverID = championship_scoring.DriverID
SET championship_scoring.Bonus_Points = championship_scoring.Bonus_Points + bonus_points.Punkte
WHERE (bonus_points.Wert = 1) AND (bonus_points.Bewertung = "FQL") AND (race_results.FastestQualifier = 1);
END$$

--
-- Funktionen
--
DROP FUNCTION IF EXISTS `SPLIT_STR`$$
CREATE DEFINER=`root`@`localhost` FUNCTION `SPLIT_STR` (`x` VARCHAR(255), `delim` VARCHAR(12), `pos` INT) RETURNS VARCHAR(255) CHARSET utf8mb4 NO SQL
RETURN REPLACE(SUBSTRING(SUBSTRING_INDEX(x, delim, pos),
       LENGTH(SUBSTRING_INDEX(x, delim, pos -1)) + 1),
       delim, '')$$

DELIMITER ;
