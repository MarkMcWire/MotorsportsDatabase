
-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `sprint_points`
--

DROP TABLE IF EXISTS `sprint_points`;
CREATE TABLE `sprint_points` (
  `Scoring` int NOT NULL,
  `Saison` int NOT NULL DEFAULT '0',
  `Mileage` int NOT NULL DEFAULT '0',
  `Wert` int NOT NULL,
  `Punkte` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- TRUNCATE Tabelle vor dem Einfügen `sprint_points`
--

TRUNCATE TABLE `sprint_points`;
--
-- Daten für Tabelle `sprint_points`
--

INSERT INTO `sprint_points` (`Scoring`, `Saison`, `Mileage`, `Wert`, `Punkte`) VALUES
(1, 0, 0, 1, 10),
(1, 0, 0, 2, 9),
(1, 0, 0, 3, 8),
(1, 0, 0, 4, 7),
(1, 0, 0, 5, 6),
(1, 0, 0, 6, 5),
(1, 0, 0, 7, 4),
(1, 0, 0, 8, 3),
(1, 0, 0, 9, 2),
(1, 0, 0, 10, 1);
