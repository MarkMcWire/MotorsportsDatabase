
--
-- Indizes der exportierten Tabellen
--

--
-- Indizes für die Tabelle `bonus_points`
--
ALTER TABLE `bonus_points`
  ADD UNIQUE KEY `Wertung_2` (`Scoring`,`Saison`,`Mileage`,`Bewertung`,`Wert`) USING BTREE,
  ADD KEY `Wert` (`Wert`);

--
-- Indizes für die Tabelle `championship`
--
ALTER TABLE `championship`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `RennID` (`RaceID`),
  ADD KEY `ID` (`ID`);

--
-- Indizes für die Tabelle `championship_scoring`
--
ALTER TABLE `championship_scoring`
  ADD KEY `DriverID` (`DriverID`),
  ADD KEY `ChampionshipID` (`ChampionshipID`) USING BTREE;

--
-- Indizes für die Tabelle `drivers`
--
ALTER TABLE `drivers`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `ID` (`ID`);

--
-- Indizes für die Tabelle `led_laps_results`
--
ALTER TABLE `led_laps_results`
  ADD PRIMARY KEY (`RaceID`,`DriverID`),
  ADD UNIQUE KEY `stage_index` (`RaceID`,`DriverID`),
  ADD KEY `DriverID` (`DriverID`);

--
-- Indizes für die Tabelle `penalties`
--
ALTER TABLE `penalties`
  ADD PRIMARY KEY (`RaceID`,`DriverID`) USING BTREE,
  ADD KEY `DriverID` (`DriverID`);

--
-- Indizes für die Tabelle `qualification_results`
--
ALTER TABLE `qualification_results`
  ADD PRIMARY KEY (`RaceID`,`DriverID`),
  ADD UNIQUE KEY `qual_index` (`RaceID`,`DriverID`),
  ADD KEY `DriverID` (`DriverID`);

--
-- Indizes für die Tabelle `races`
--
ALTER TABLE `races`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ID` (`ID`),
  ADD KEY `StreckenID` (`TrackID`),
  ADD KEY `races_ibfk_2` (`TypeID`);

--
-- Indizes für die Tabelle `race_results`
--
ALTER TABLE `race_results`
  ADD UNIQUE KEY `ResultID` (`RaceID`,`Finish`),
  ADD KEY `race_results_ibfk_2` (`DriverID`);

--
-- Indizes für die Tabelle `race_result_colors`
--
ALTER TABLE `race_result_colors`
  ADD PRIMARY KEY (`Finish`);

--
-- Indizes für die Tabelle `sprint_results`
--
ALTER TABLE `sprint_results`
  ADD UNIQUE KEY `ResultID` (`RaceID`,`SprintID`,`Finish`) USING BTREE,
  ADD KEY `race_results_ibfk_2` (`DriverID`);

--
-- Indizes für die Tabelle `stage_results`
--
ALTER TABLE `stage_results`
  ADD PRIMARY KEY (`RaceID`,`DriverID`,`StageID`) USING BTREE,
  ADD UNIQUE KEY `stage_index` (`RaceID`,`DriverID`,`StageID`) USING BTREE,
  ADD KEY `stage_results_ibfk_2` (`DriverID`);

--
-- Indizes für die Tabelle `tracks`
--
ALTER TABLE `tracks`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `ID` (`ID`);

--
-- Indizes für die Tabelle `track_type`
--
ALTER TABLE `track_type`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT für exportierte Tabellen
--

--
-- AUTO_INCREMENT für Tabelle `championship`
--
ALTER TABLE `championship`
  MODIFY `ID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5655;

--
-- Constraints der exportierten Tabellen
--

--
-- Constraints der Tabelle `championship`
--
ALTER TABLE `championship`
  ADD CONSTRAINT `championship_ibfk_1` FOREIGN KEY (`RaceID`) REFERENCES `races` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints der Tabelle `championship_scoring`
--
ALTER TABLE `championship_scoring`
  ADD CONSTRAINT `championship_scoring_ibfk_1` FOREIGN KEY (`ChampionshipID`) REFERENCES `championship` (`ID`) ON DELETE RESTRICT ON UPDATE CASCADE,
  ADD CONSTRAINT `championship_scoring_ibfk_2` FOREIGN KEY (`DriverID`) REFERENCES `drivers` (`ID`) ON DELETE RESTRICT ON UPDATE CASCADE;

--
-- Constraints der Tabelle `led_laps_results`
--
ALTER TABLE `led_laps_results`
  ADD CONSTRAINT `led_laps_results_ibfk_1` FOREIGN KEY (`RaceID`) REFERENCES `races` (`ID`) ON DELETE RESTRICT ON UPDATE CASCADE,
  ADD CONSTRAINT `led_laps_results_ibfk_2` FOREIGN KEY (`DriverID`) REFERENCES `drivers` (`ID`) ON DELETE RESTRICT ON UPDATE CASCADE;

--
-- Constraints der Tabelle `penalties`
--
ALTER TABLE `penalties`
  ADD CONSTRAINT `penalties_ibfk_1` FOREIGN KEY (`RaceID`) REFERENCES `races` (`ID`) ON DELETE RESTRICT ON UPDATE CASCADE,
  ADD CONSTRAINT `penalties_ibfk_2` FOREIGN KEY (`DriverID`) REFERENCES `drivers` (`ID`) ON DELETE RESTRICT ON UPDATE CASCADE;

--
-- Constraints der Tabelle `qualification_results`
--
ALTER TABLE `qualification_results`
  ADD CONSTRAINT `qualification_results_ibfk_1` FOREIGN KEY (`RaceID`) REFERENCES `races` (`ID`) ON DELETE RESTRICT ON UPDATE CASCADE,
  ADD CONSTRAINT `qualification_results_ibfk_2` FOREIGN KEY (`DriverID`) REFERENCES `drivers` (`ID`) ON DELETE RESTRICT ON UPDATE CASCADE;

--
-- Constraints der Tabelle `races`
--
ALTER TABLE `races`
  ADD CONSTRAINT `races_ibfk_1` FOREIGN KEY (`TrackID`) REFERENCES `tracks` (`ID`) ON DELETE RESTRICT ON UPDATE CASCADE,
  ADD CONSTRAINT `races_ibfk_2` FOREIGN KEY (`TypeID`) REFERENCES `track_type` (`ID`) ON DELETE RESTRICT ON UPDATE CASCADE;

--
-- Constraints der Tabelle `race_results`
--
ALTER TABLE `race_results`
  ADD CONSTRAINT `race_results_ibfk_1` FOREIGN KEY (`RaceID`) REFERENCES `races` (`ID`) ON DELETE RESTRICT ON UPDATE CASCADE,
  ADD CONSTRAINT `race_results_ibfk_2` FOREIGN KEY (`DriverID`) REFERENCES `drivers` (`ID`) ON DELETE RESTRICT ON UPDATE CASCADE;

--
-- Constraints der Tabelle `sprint_results`
--
ALTER TABLE `sprint_results`
  ADD CONSTRAINT `sprint_results_ibfk_1` FOREIGN KEY (`RaceID`) REFERENCES `races` (`ID`) ON DELETE RESTRICT ON UPDATE CASCADE,
  ADD CONSTRAINT `sprint_results_ibfk_2` FOREIGN KEY (`DriverID`) REFERENCES `drivers` (`ID`) ON DELETE RESTRICT ON UPDATE CASCADE;

--
-- Constraints der Tabelle `stage_results`
--
ALTER TABLE `stage_results`
  ADD CONSTRAINT `stage_results_ibfk_1` FOREIGN KEY (`RaceID`) REFERENCES `races` (`ID`) ON DELETE RESTRICT ON UPDATE CASCADE,
  ADD CONSTRAINT `stage_results_ibfk_2` FOREIGN KEY (`DriverID`) REFERENCES `drivers` (`ID`) ON DELETE RESTRICT ON UPDATE CASCADE;
