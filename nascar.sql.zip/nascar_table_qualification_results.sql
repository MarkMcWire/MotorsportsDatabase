
-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `qualification_results`
--

DROP TABLE IF EXISTS `qualification_results`;
CREATE TABLE `qualification_results` (
  `RaceID` int NOT NULL,
  `DriverID` int NOT NULL,
  `Session` varchar(8) NOT NULL,
  `Time` time NOT NULL,
  `Position` int NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- TRUNCATE Tabelle vor dem Einfügen `qualification_results`
--

TRUNCATE TABLE `qualification_results`;