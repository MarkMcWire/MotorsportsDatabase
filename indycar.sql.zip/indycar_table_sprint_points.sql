
-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `sprint_points`
--

DROP TABLE IF EXISTS `sprint_points`;
CREATE TABLE `sprint_points` (
  `Scoring` int NOT NULL,
  `Saison` int NOT NULL DEFAULT '0',
  `Mileage` int NOT NULL DEFAULT '0',
  `Wert` int NOT NULL,
  `Punkte` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- TRUNCATE Tabelle vor dem Einfügen `sprint_points`
--

TRUNCATE TABLE `sprint_points`;
--
-- Daten für Tabelle `sprint_points`
--

INSERT INTO `sprint_points` (`Scoring`, `Saison`, `Mileage`, `Wert`, `Punkte`) VALUES
(1, 0, 0, 1, 8),
(1, 0, 0, 2, 7),
(1, 0, 0, 3, 6),
(1, 0, 0, 4, 5),
(1, 0, 0, 5, 4),
(1, 0, 0, 6, 3),
(1, 0, 0, 7, 2),
(1, 0, 0, 8, 1),
(2, 0, 0, 1, 10),
(2, 0, 0, 2, 9),
(2, 0, 0, 3, 8),
(2, 0, 0, 4, 7),
(2, 0, 0, 5, 6),
(2, 0, 0, 6, 5),
(2, 0, 0, 7, 4),
(2, 0, 0, 8, 3),
(2, 0, 0, 9, 2),
(2, 0, 0, 10, 1),
(3, 2014, 0, 1, 9),
(3, 2014, 0, 2, 8),
(3, 2014, 0, 3, 7),
(3, 2014, 0, 4, 6),
(3, 2014, 0, 5, 5),
(3, 2014, 0, 6, 4),
(3, 2014, 0, 7, 3),
(3, 2014, 0, 8, 2),
(3, 2014, 0, 9, 1),
(3, 2014, 0, 10, 1);
