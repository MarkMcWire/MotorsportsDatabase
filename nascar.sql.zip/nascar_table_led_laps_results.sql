
-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `led_laps_results`
--

DROP TABLE IF EXISTS `led_laps_results`;
CREATE TABLE `led_laps_results` (
  `RaceID` int NOT NULL,
  `DriverID` int NOT NULL,
  `LedLaps` int NOT NULL,
  `MostLapsLed` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- TRUNCATE Tabelle vor dem Einfügen `led_laps_results`
--

TRUNCATE TABLE `led_laps_results`;