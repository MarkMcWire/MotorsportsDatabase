
DELIMITER $$
--
-- Prozeduren
--
DROP PROCEDURE IF EXISTS `10_Fahrerduplikate_im_Hauptrennen_finden`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `10_Fahrerduplikate_im_Hauptrennen_finden` ()  READS SQL DATA
SELECT RaceID, race_results.DriverID, COUNT(Finish) FROM race_results GROUP BY RaceID, race_results.DriverID HAVING COUNT(Finish) > 1$$

DROP PROCEDURE IF EXISTS `10_Fahrerduplikate_im_Sprintennen_finden`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `10_Fahrerduplikate_im_Sprintennen_finden` ()  READS SQL DATA
SELECT RaceID, sprint_results.DriverID, COUNT(Finish) FROM sprint_results GROUP BY RaceID, SprintID, sprint_results.DriverID HAVING COUNT(Finish) > 1$$

DROP PROCEDURE IF EXISTS `11_Datenfehler_im Hauptrennen_finden`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `11_Datenfehler_im Hauptrennen_finden` ()  READS SQL DATA
BEGIN
SELECT RaceID, COUNT(DISTINCT Start), MAX(Start), COUNT(DISTINCT Finish), Max(Finish) FROM race_results GROUP BY RaceID HAVING COUNT(DISTINCT Start) <> COUNT(DISTINCT Finish) OR (MAX(Start) <> MAX(Finish)) OR (COUNT(DISTINCT Finish) <> MAX(Finish)) ORDER BY RaceID DESC Limit 25;

SELECT RaceID, SUM(Led), MAX(Laps) FROM race_results GROUP BY RaceID HAVING (SUM(Led) <> MAX(Laps)) ORDER BY RaceID DESC;
END$$

DROP PROCEDURE IF EXISTS `11_Datenfehler_im Sprintrennen_finden`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `11_Datenfehler_im Sprintrennen_finden` ()  READS SQL DATA
BEGIN
SELECT RaceID, COUNT(DISTINCT Start), MAX(Start), COUNT(DISTINCT Finish), Max(Finish) FROM sprint_results GROUP BY RaceID, SprintID HAVING COUNT(DISTINCT Start) <> COUNT(DISTINCT Finish) OR (MAX(Start) <> MAX(Finish)) OR (COUNT(DISTINCT Finish) <> MAX(Finish)) ORDER BY RaceID DESC Limit 25;

SELECT RaceID, SUM(Led), MAX(Laps) FROM sprint_results GROUP BY RaceID, SprintID HAVING (SUM(Led) <> MAX(Laps)) ORDER BY RaceID DESC;
END$$

DROP PROCEDURE IF EXISTS `21_Meisterschaft_anlegen`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `21_Meisterschaft_anlegen` ()  BEGIN
INSERT INTO championship (Bezeichnung, Saison, RaceID, Kategorie)
SELECT 'Formula One World Championship', YEAR(races.Datum), races.ID, 1 FROM races LEFT JOIN championship ON championship.RaceID = races.ID WHERE (championship.ID IS NULL) AND (races.ID MOD 10 IN (1,2));

INSERT INTO championship (Bezeichnung, Saison, RaceID, Kategorie)
SELECT 'IndyCar Series', YEAR(races.Datum), races.ID, 1 FROM races LEFT JOIN championship ON championship.RaceID = races.ID WHERE (championship.ID IS NULL) AND (races.ID MOD 10 IN (3,4,5));

UPDATE championship LEFT JOIN races ON races.ID = championship.RaceID SET races.Event = Concat(championship.Saison, '–') WHERE (races.Event = '') OR (races.Event IS NULL);

UPDATE championship LEFT JOIN races ON races.ID = championship.RaceID LEFT JOIN (SELECT MAX(Finish) AS Autos, RaceID FROM race_results GROUP BY RaceID) AS TempTable ON TempTable.RaceID = races.ID SET championship.Autos = TempTable.Autos WHERE TempTable.Autos IS NOT NULL;

UPDATE championship SET championship.Mileage = 0;
END$$

DROP PROCEDURE IF EXISTS `22_Resort_ChampionshipID`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `22_Resort_ChampionshipID` ()  MODIFIES SQL DATA
BEGIN
SET @max_id = 0;

SELECT COUNT(ID) + 1 INTO @max_id FROM championship;

UPDATE championship LEFT JOIN (SELECT m1.ID, m1.RaceID, count(m2.ID) as NewID FROM `championship` as m1 left join `championship` as m2 on m1.ID >= m2.ID group by m1.ID, m1.RaceID) As Temp on Temp.ID = championship.ID set championship.ID = 10 * Temp.RaceID + 2 * championship.Kategorie + (Temp.NewID mod 10);

UPDATE championship LEFT JOIN (SELECT m1.ID, m1.RaceID, count(m2.ID) as NewID FROM `championship` as m1 left join `championship` as m2 on m1.ID >= m2.ID group by m1.ID, m1.RaceID) As Temp on Temp.ID = championship.ID set championship.ID = Temp.NewID;

SET @sql = CONCAT('ALTER TABLE `championship` AUTO_INCREMENT = ', @max_id);
PREPARE st FROM @sql;
EXECUTE st;

END$$

DROP PROCEDURE IF EXISTS `31_Resort_DriverID`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `31_Resort_DriverID` ()  MODIFIES SQL DATA
BEGIN

UPDATE drivers INNER JOIN race_results ON race_results.DriverID = drivers.ID
SET drivers.Kategorie = 100*race_results.RaceID + race_results.Finish;

UPDATE drivers INNER JOIN race_results ON race_results.DriverID = drivers.ID
SET drivers.ID = drivers.Kategorie - 1.9e+10 WHERE drivers.Kategorie > 0;

UPDATE drivers LEFT JOIN (SELECT d1.ID, d1.Kategorie, count(d2.ID) as NewID FROM `drivers` as d1 left join `drivers` as d2 on d1.ID >= d2.ID group by d1.ID, d1.Kategorie) As Temp on Temp.ID = drivers.ID set drivers.ID = Temp.NewID;

END$$

DROP PROCEDURE IF EXISTS `32_Resort_TrackID`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `32_Resort_TrackID` ()  MODIFIES SQL DATA
BEGIN

UPDATE tracks INNER JOIN races ON races.TrackID = tracks.ID
SET tracks.Kategorie = races.ID;

UPDATE tracks INNER JOIN races ON races.TrackID = tracks.ID
SET tracks.ID = tracks.Kategorie WHERE tracks.Kategorie > 0;

UPDATE tracks LEFT JOIN (SELECT t1.ID, t1.Kategorie, count(t2.ID)-1 as NewID FROM `tracks` as t1 left join `tracks` as t2 on t1.ID >= t2.ID group by t1.ID, t1.Kategorie) As Temp on Temp.ID = tracks.ID set tracks.ID = Temp.NewID;

END$$

DROP PROCEDURE IF EXISTS `41_Punktesysteme_festlegen`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `41_Punktesysteme_festlegen` ()  MODIFIES SQL DATA
BEGIN
UPDATE championship SET championship.Qualification_Scoring = 1 WHERE RaceID IN (SELECT RaceID FROM qualification_results);

UPDATE championship SET championship.Stage_Scoring = 1 WHERE RaceID IN (SELECT RaceID FROM stage_results);

UPDATE championship SET championship.Sprint_Scoring = 1 WHERE RaceID IN (SELECT RaceID FROM sprint_results) AND (championship.Bezeichnung like "%Formula%");
UPDATE championship SET championship.Sprint_Scoring = 2 WHERE RaceID IN (SELECT RaceID FROM sprint_results) AND (championship.Bezeichnung like "%IndyCar%");
UPDATE championship SET championship.Sprint_Scoring = 3 WHERE RaceID IN (SELECT RaceID FROM sprint_results) AND (RaceID MOD 10 IN (6,7,8));

UPDATE championship LEFT JOIN races ON races.ID = championship.RaceID LEFT JOIN tracks ON tracks.ID = races.TrackID SET championship.Race_Scoring = 1 WHERE (championship.Bezeichnung like "%Formula%");
UPDATE championship LEFT JOIN races ON races.ID = championship.RaceID LEFT JOIN tracks ON tracks.ID = races.TrackID SET championship.Race_Scoring = 2 WHERE (championship.Bezeichnung like "%IndyCar%");
UPDATE championship LEFT JOIN races ON races.ID = championship.RaceID LEFT JOIN tracks ON tracks.ID = races.TrackID SET championship.Race_Scoring = 3 WHERE (races.ID MOD 10 IN (6,7,8));

UPDATE championship LEFT JOIN races ON races.ID = championship.RaceID LEFT JOIN tracks ON tracks.ID = races.TrackID SET championship.Bonus_Scoring = 1 WHERE (championship.Bezeichnung like "%Formula%");
UPDATE championship LEFT JOIN races ON races.ID = championship.RaceID LEFT JOIN tracks ON tracks.ID = races.TrackID SET championship.Bonus_Scoring = 2 WHERE (championship.Bezeichnung like "%IndyCar%");
UPDATE championship LEFT JOIN races ON races.ID = championship.RaceID LEFT JOIN tracks ON tracks.ID = races.TrackID SET championship.Bonus_Scoring = 3 WHERE (races.ID MOD 10 IN (6,7,8));
END$$

--
-- Funktionen
--
DROP FUNCTION IF EXISTS `SPLIT_STR`$$
CREATE DEFINER=`root`@`localhost` FUNCTION `SPLIT_STR` (`x` VARCHAR(255), `delim` VARCHAR(12), `pos` INT) RETURNS VARCHAR(255) CHARSET utf8mb4 NO SQL
RETURN REPLACE(SUBSTRING(SUBSTRING_INDEX(x, delim, pos),
       LENGTH(SUBSTRING_INDEX(x, delim, pos -1)) + 1),
       delim, '')$$

DELIMITER ;
