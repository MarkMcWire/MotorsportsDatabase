
-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `bonus_points`
--

DROP TABLE IF EXISTS `bonus_points`;
CREATE TABLE `bonus_points` (
  `Scoring` int NOT NULL,
  `Saison` int NOT NULL DEFAULT '0',
  `Mileage` int NOT NULL DEFAULT '0',
  `Bewertung` varchar(50) NOT NULL,
  `Wert` int NOT NULL,
  `Punkte` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- TRUNCATE Tabelle vor dem Einfügen `bonus_points`
--

TRUNCATE TABLE `bonus_points`;
--
-- Daten für Tabelle `bonus_points`
--

INSERT INTO `bonus_points` (`Scoring`, `Saison`, `Mileage`, `Bewertung`, `Wert`, `Punkte`) VALUES
(2, 0, 0, 'LL', 1, 5),
(2, 0, 0, 'MLL', 1, 5),
(3, 0, 0, 'FQ', 1, 2),
(3, 0, 0, 'MLL', 1, 2),
(10, 0, 0, 'FL', 1, 1),
(11, 0, 0, 'FQ', 1, 1),
(11, 0, 0, 'MLL', 1, 1);
