
-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `stage_results`
--

DROP TABLE IF EXISTS `stage_results`;
CREATE TABLE `stage_results` (
  `RaceID` int NOT NULL,
  `StageID` int NOT NULL,
  `DriverID` int NOT NULL,
  `Laps` int NOT NULL,
  `Position` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- TRUNCATE Tabelle vor dem Einfügen `stage_results`
--

TRUNCATE TABLE `stage_results`;