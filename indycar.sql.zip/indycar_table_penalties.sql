
-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `penalties`
--

DROP TABLE IF EXISTS `penalties`;
CREATE TABLE `penalties` (
  `RaceID` int NOT NULL,
  `DriverID` int NOT NULL,
  `Points` int NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- TRUNCATE Tabelle vor dem Einfügen `penalties`
--

TRUNCATE TABLE `penalties`;
--
-- Daten für Tabelle `penalties`
--

INSERT INTO `penalties` (`RaceID`, `DriverID`, `Points`) VALUES
(202403103, 1378, -10);
